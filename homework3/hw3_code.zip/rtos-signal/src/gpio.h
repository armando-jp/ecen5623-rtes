/*
 * gpio.h
 *
 *  Created on: Mar 21, 2022
 *      Author: arman
 */

#ifndef SRC_GPIO_H_
#define SRC_GPIO_H_

void gpio_enable_peripheral();
void gpio_configure_leds();
void gpio_toggle_led1();
void gpio_on_led1();

#endif /* SRC_GPIO_H_ */
