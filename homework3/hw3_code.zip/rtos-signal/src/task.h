/*
 * task.h
 *
 *  Created on: Mar 22, 2022
 *      Author: arman
 */

#ifndef SRC_TASK_H_
#define SRC_TASK_H_

void task1();

#endif /* SRC_TASK_H_ */
